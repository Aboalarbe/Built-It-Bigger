package com.example.aboalarbe;

public class Joke {
    private static String[]jokes=new String[]{
            "What is the difference between a snowman and a snowwoman?\n" +
                    "-\n" +
                    "Snowballs.",
            "Police officer: \"Can you identify yourself, sir?\"\n" +
                    " \n" +
                    "Driver pulls out his mirror and says: \"Yes, it's me.",
            "Dentist: \"You need a crown.\"\n" +
                    "-\n" +
                    "Patient: \"Finally someone who understands me",
            "Coco Chanel once said that you should put perfume on places where you want to be kissed by a man. But hell does that burn!.",
            "In Spain, there is a tradition after a bullfight to serve the mayor the bull’s testicles.\n" +
                    "-\n" +
                    "One day after a bullfight, the mayor asks the waiter: “Funny, why are they so small today?”\n" +
                    "-\n" +
                    "The waiter: “Today, sir, the bull women.",
            "I change my password to 'incorrect' \n" +
                    "so whenever i forget what it is \n" +
                    " the computer will say 'your password is incorrect.' "
    };
    private static int getRandomJoke()
    {
        return (int)(Math.random()*jokes.length);
    }
    public static String getJoke()
    {
        return jokes[getRandomJoke()];
    }
}
