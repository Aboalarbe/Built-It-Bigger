package com.udacity.gradle.builditbigger;

import android.os.Build;
import android.support.annotation.RequiresApi;
import android.util.Log;

import org.junit.Test;

import java.util.concurrent.TimeUnit;

import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class MyUnitTest {
    private static final String TAG="UNITTEST";
    @RequiresApi(api = Build.VERSION_CODES.CUPCAKE)
    @Test
    public void testBackendResult() throws Exception{
        try {
            MainActivity mainContext=new MainActivity();
            MainActivity.EndpointsAsyncTask endpointsAsyncTask = new MainActivity.EndpointsAsyncTask();
            endpointsAsyncTask.execute(mainContext);
            String result = endpointsAsyncTask.get(40, TimeUnit.SECONDS);
            assertNotNull(result);
            assertTrue(result.length() > 0);
        } catch (Exception e){
            Log.e(TAG, "Result: Time out");
        }
    }
}
