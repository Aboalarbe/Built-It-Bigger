package com.udacity.gradle.builditbigger;

import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;


/**
 * Created by m_abo on 4/20/2017.
 */

public class NetworkUtilities {
    public static void tellJoke(Activity activity, ProgressBar bar) {
        if (NetworkUtilities.isConnected(activity)) {
            bar.setVisibility(View.VISIBLE);
            new MainActivity.EndpointsAsyncTask().execute(activity);
        } else {
            Toast.makeText(activity, "Check your Connection", Toast.LENGTH_SHORT).show();
            bar.setVisibility(View.GONE);
        }
    }

    public static boolean isConnected(Activity activity) {
        ConnectivityManager conn = (ConnectivityManager) activity.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = conn.getActiveNetworkInfo();
        if (info != null && info.isConnectedOrConnecting())
            return true;
        else
            return false;
    }
}
